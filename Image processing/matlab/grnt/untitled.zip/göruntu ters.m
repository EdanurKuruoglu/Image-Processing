img = imread('lena.jpg');
y_ters_img = flip(img, 1);
imshow(y_ters_img);