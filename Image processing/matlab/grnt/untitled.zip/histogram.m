I1 = imread('lena.jpg');
imhist(I1)