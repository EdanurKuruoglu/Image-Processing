orijinalGoruntu = imread('lena.jpg');
xEksenindeAynalama = fliplr(orijinalGoruntu);
imshow(xEksenindeAynalama)