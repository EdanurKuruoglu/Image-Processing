I1 = imread('lena.jpg');
I2 = imresize(I1,[100 150])
imshow(I2);