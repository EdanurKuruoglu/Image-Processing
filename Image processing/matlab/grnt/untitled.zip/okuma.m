resim = imread('lena.jpg');
imshow(resim);