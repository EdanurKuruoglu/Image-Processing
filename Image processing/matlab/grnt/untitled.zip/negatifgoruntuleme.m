I1 = imread('lena.jpg');
I2 = imcomplement(I1);
imshow(I2);